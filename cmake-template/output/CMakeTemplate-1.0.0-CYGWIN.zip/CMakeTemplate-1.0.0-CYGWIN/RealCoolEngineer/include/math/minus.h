// Author: Farmer Li, 公众号: 很酷的程序员/RealCoolEngineer
// Date: 2021-05-10

#ifndef SRC_C_MATH_MINUS_H_
#define SRC_C_MATH_MINUS_H_

#ifdef __cplusplus
extern "C" {
#endif

int minus_int(int x, int y);

#ifdef __cplusplus
}
#endif

#endif  // SRC_C_MATH_MINUS_H_
